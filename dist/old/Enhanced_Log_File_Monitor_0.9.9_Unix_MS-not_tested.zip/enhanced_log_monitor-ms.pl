#!/usr/bin/perl
use strict;

# get all the variables from the environmental variable
my $dir            = $ENV{'UPTIME_DIR'};
my $files_regex    = $ENV{'UPTIME_FILES_REGEX'};
my $search_regex   = $ENV{'UPTIME_SEARCH_REGEX'};
my $ignore_regex   = $ENV{'UPTIME_IGNORE_REGEX'};
my $debug_mode     = $ENV{'UPTIME_DEBUG_MODE'};
my $agent_hostname = $ENV{'UPTIME_HOSTNAME'};
my $agent_port     = $ENV{'UPTIME_PORT'};
my $agent_password = $ENV{'UPTIME_PASSWORD'};

my $tmpfile = $agent_hostname . '.' . $$;	# temp file used to store output from agent
my $cmdlinevar = '';	# create the one variable for the command line and parse from the main 4 variables


# determine if the agent is a Windows or other (posix) agent since the Windows agent requires special handling
sub is_windows_agent {
	my $hostname = $_[0];
	my $port = $_[1];
	
	my $tmp = $hostname . '.' . $$;	# temp file used to store output from agent
	my $rv = 0;
	# run the netcat command and save it to the temp file
	`echo ver | nc $hostname $port 2>&1 >$tmp`;
	# output the temp file
	open (TEMPFILE, "<$tmp") || die("Could not open temp file on monitoring station! Filename: $tmp\n");
	my $lines = 1;
	while (<TEMPFILE>) {
		$lines++;
		if ($_ =~ /windows/i) {
			$rv = 1;
		}
	}
	close (TEMPFILE);
	if ($lines == 0) {
		$rv = 0;
		#print "Error: no lines returned";
	}
	# delete the temp file
	unlink($tmp);
	return $rv;
}

# replace spaces for the string "UPSPCTIME"
$dir          =~ s/ /(UPSPCTIME)/g;
$files_regex  =~ s/ /(UPSPCTIME)/g;
$search_regex =~ s/ /(UPSPCTIME)/g;
$ignore_regex =~ s/ /(UPSPCTIME)/g;

# "UPDOTTIME" separates each variable
my $break = 'UPDOTTIME';
$cmdlinevar = $dir . $break .
			  $files_regex . $break .
			  $search_regex . $break .
			  $ignore_regex . $break .
			  $debug_mode;

# run the netcat command and save it to the temp file
if (is_windows_agent($agent_hostname, $agent_port)) {
	`echo rexec $agent_password logmonitor $cmdlinevar | nc $agent_hostname $agent_port 2>&1 >$tmpfile`;
}
else {
	`echo rexec $agent_password /opt/uptime-agent/scripts/log_monitor.pl $cmdlinevar | nc $agent_hostname $agent_port 2>&1 >$tmpfile`;
}
# output the temp file
open (TEMPFILE, "<$tmpfile") || die("Could not open temp file on monitoring station! Filename: $tmpfile\n");
while (<TEMPFILE>) {
	print $_;
}
close (TEMPFILE);

# delete the temp file
unlink($tmpfile);
