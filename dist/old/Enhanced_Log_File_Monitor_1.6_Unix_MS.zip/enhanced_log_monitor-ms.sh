#!/bin/sh
../../apache/bin/php enhanced_log_monitor-ms.php

